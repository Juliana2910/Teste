<?php
/*
* Desenvolvedor : Juliana E. Antunes
* Data : 22/12/2020
* Objetivo : Classes de modelo
*/


/*
* Modelo do Produto
*/
class Produto{
	public $IdProd;
	public $Nome;
	public $Cor;
	public $Preco;
	public $PercDesconto;
}

/*
* Modelo do Preço
*/
class Preco{
	public $IdPreco;
	public $Preco;
}

?>
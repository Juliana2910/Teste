<?php
/*
* Desenvolvedor : Juliana E. Antunes
* Data : 22/12/2020
* Objetivo : Controller do Produto
*/


/*
* Classe responsável pelo Controller do Produto
*/
class ProdutosController{
	
	/*
	* Obtém Produto por ID
	*/
	function Obter($IdProd){	
			$conn = mysqli_connect("localhost","root","","loja");
			
			if (mysqli_connect_errno()) {
			  echo "Falha na conexão MySQL: " . mysqli_connect_error();
			  exit();
			}
			
			$result = mysqli_query($conn,"SELECT PRD.IDPROD,PRD.NOME,PRD.COR,PRC.PRECO,PRC.IDPRECO FROM PRODUTOS PRD INNER JOIN PRECO PRC ON PRC.IDPRECO = PRD.IDPRECO WHERE IDPROD = " . $IdProd);

			
			while ($row = $result->fetch_row()) {
				$objProduto = new Produto();
				$objProduto->IdProd = $row[0];
				
				$objProduto->Nome = $row[1];
				$objProduto->Cor = $row[2];
				$objProduto->Preco = new Preco();
				$objProduto->Preco->IdPreco = $row[4];;
				$objProduto->Preco->Preco = $row[3];
				
				$produto = $objProduto;
				
			}
			
			mysqli_close($conn);
			
			return $produto;	
	}

	/*
	* Obtém Listagem de Produtos podendo ser filtrado por ID
	*/
	function Listar($filtro){	
		
		$conn = mysqli_connect("localhost","root","","loja");
		
		if (mysqli_connect_errno()) {
		  echo "Falha na conexão MySQL: " . mysqli_connect_error();
		  exit();
		}
		
		if(!empty($filtro))
		{
			$andSQL = false;
			
			$sqlFiltro = "SELECT PRD.IDPROD,PRD.NOME,PRD.COR,PRC.PRECO,PRC.IDPRECO FROM PRODUTOS PRD INNER JOIN PRECO PRC ON PRC.IDPRECO = PRD.IDPRECO WHERE";
			if(!empty($filtro["FiltroNome"])){
				$sqlFiltro = $sqlFiltro . " PRD.NOME LIKE '%" . $filtro["FiltroNome"] ."%'";
				$andSQL = true;
			}
			
			if(!empty($filtro["FiltroCor"])){
				if($andSQL){
					$sqlFiltro = $sqlFiltro . ' AND ';
				}
				$sqlFiltro = $sqlFiltro . " PRD.COR LIKE '%" . $filtro["FiltroCor"] ."%'";
				$andSQL = true;
			}
			
			if(!empty($filtro["FiltroPrecoValor"])){
				if($andSQL){
					$sqlFiltro = $sqlFiltro . ' AND ';
				}
				$sqlFiltro = $sqlFiltro . " PRD.COR LIKE '%" . $filtro["FiltroCor"] ."%'";
				$andSQL = true;
				$sqlFiltro = $sqlFiltro . " AND PRC.PRECO " . $filtro['FiltroPrecoCondicao'] . " ". $filtro['FiltroPrecoValor'] ;
				$andSQL = true;
			}
			$result = mysqli_query($conn,$sqlFiltro);
		}else{
			$sql = "SELECT PRD.IDPROD,PRD.NOME,PRD.COR,PRC.PRECO,PRC.IDPRECO FROM PRODUTOS PRD INNER JOIN PRECO PRC ON PRC.IDPRECO = PRD.IDPRECO";
			$result = mysqli_query($conn,$sql);
		}
		
		$listProdutos = null;
		
		while ($row = $result->fetch_row()) {
			$objProduto = new Produto();
			$objProduto->IdProd = $row[0];
			
			$objProduto->Nome = $row[1];
			$objProduto->Cor = $row[2];
			$objProduto->Preco = new Preco();
			$objProduto->Preco->IdPreco = $row[4];;
			$objProduto->Preco->Preco = $row[3];
			
			$listProdutos[] = $objProduto;
		}
		
		mysqli_close($conn);
		
		return $listProdutos;	
	}
	
	/*
	* Altera Produto
	*/
	function Alterar($produto){
		$conn = mysqli_connect("localhost","root","","loja");
		
		if (mysqli_connect_errno()) {
		  echo "Falha na conexão MySQL: " . mysqli_connect_error();
		  exit();
		}
		
		$sql = "INSERT INTO PRECO(PRECO) VALUES (" . $produto->Preco->Preco . ")";
		mysqli_query($conn,$sql);
		$idPreco = mysqli_insert_id($conn);
		
		$sql = "UPDATE PRODUTOS SET NOME = '" . $produto->Nome. "', IDPRECO = " . $idPreco . " WHERE IDPROD = " . $produto->IdProd;
		mysqli_query($conn,$sql);
		
		mysqli_close($conn);
	}
	
	/*
	* Deleta Produto
	*/
	function Deletar($idProduto){
		$conn = mysqli_connect("localhost","root","","loja");
		
		if (mysqli_connect_errno()) {
		  echo "Falha na conexão MySQL: " . mysqli_connect_error();
		  exit();
		}
		
		mysqli_query($conn,"DELETE FROM PRODUTOS WHERE IDPROD = " . $idProduto);
		
		mysqli_close($conn);
	}
	
	/*
	* Insere Produto
	*/
	function Inserir($produto){
		$conn = mysqli_connect("localhost","root","","loja");
		
		if (mysqli_connect_errno()) {
		  echo "Falha na conexão MySQL: " . mysqli_connect_error();
		  exit();
		}
		$sql = "INSERT INTO PRECO(PRECO) VALUES (" . $produto->Preco->Preco . ")";
		mysqli_query($conn,$sql);
		$idPreco = mysqli_insert_id($conn);
		
		$sql = "INSERT INTO PRODUTOS(NOME,COR,IDPRECO) VALUES ('" . $produto->Nome ."','" . $produto->Cor . "'," . $idPreco . ")";
		mysqli_query($conn,$sql);
		
		mysqli_close($conn);
	}
	
	/*
	* Obtem Constante de Cores para popular DropDow
	*/
	function ObterCores(){
		$cores["vermelho"] = "Vermelho";
		$cores["azul"] = "Azul";
		$cores["amarelo"] = "Amarelo";
		
		return $cores;
	}
	
	/*
	* Regra de negócio solicitada no documento para mostrar desconto
	* OBS : Não estou aplicando o Desconto no Subtotal de cada item, não sei se é necessário.
	*/
	function RegraDeDesconto($listProdutos){
		foreach($listProdutos as $produto){
			if($produto->Cor == 'azul' || $produto->Cor == 'vermelho'){
				$produto->PercDesconto = "20%";
			}
			
			if($produto->Cor == 'amarelo'){
				$produto->PercDesconto = "10%";
			}
			
			if($produto->Cor == 'vermelho' && $produto->Preco->Preco > 50){
				$produto->PercDesconto = "5%";
			}
		}
		
		return $listProdutos;
	}
}

?>
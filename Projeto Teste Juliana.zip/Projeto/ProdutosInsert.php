<?php
/*
* Desenvolvedor : Juliana E. Antunes
* Data : 22/12/2020
* Objetivo : View da inserção de Produto
*/
require_once("Controller/ProdutosController.php");
require_once("Model/ProdutosModel.php");

$controller = new ProdutosController();
/* Popula DropDown de cores */
$cores = $controller->ObterCores();

if(!empty($_POST['Nome'])){
	/* Quando ação for inserir produto */
	$produto = new Produto();
	$produto->Nome = $_POST['Nome'];
	$produto->Cor = $_POST['Cor'];
	$produto->Preco = new Preco();
	$produto->Preco->Preco = $_POST['Preco'];
	

	$controller->Inserir($produto);
	
	echo "Produto Inserido com sucesso!";
	echo '<BR> <a href="ProdutosList.php">Voltar para Lista</a>';
	return;
}
?>

<html>
	<head>
		<Title>Inserção</title>
	</head>
<body>
<h1>Novo</h1>

<form action="ProdutosInsert.php" method="POST">
	<table>
		<tr>
			<td>Produto : </td>
			<td><input type="text" id="Nome" name="Nome"/></td>
		<tr>
		<tr>
			<td>Preço : </td>
			<td><input type="text" id="Preco" name="Preco"/></td>
		<tr>
		<tr>
			<td>Cor : </td>
			<td>
				<select id="Cor" name="Cor">
					<option value="false">Selecione</option>
					<?php foreach($cores as $key => $value) { ?>
					<option value="<?=$key; ?>"><?=$value; ?></option>
					<?php } ?>
				</select>
			</td>
		</tr>
		<tr>
			<td><input type="submit" value="Salvar" /></td>
		<tr>
	</table>
<form>
<?php
/*
* Desenvolvedor : Juliana E. Antunes
* Data : 22/12/2020
* Objetivo : View da Listagem de Produtos
*/

require_once("Controller/ProdutosController.php");
require_once("Model/ProdutosModel.php");


$controller = new ProdutosController();
/* Popula DropDown de cores */
$cores = $controller->ObterCores();

/* Condições para utilização do Filtro */
$filtro = null;

if(!empty($_GET['FiltroNome']) && $_GET['FiltroNome'] != "")
{
	$filtro['FiltroNome'] = $_GET['FiltroNome'];
}

if(!empty($_GET['FiltroPrecoValor'])  && $_GET['FiltroPrecoValor'] != "")
{
	$filtro['FiltroPrecoValor'] = $_GET['FiltroPrecoValor'];
}

if(!empty($_GET['FiltroPrecoCondicao']) && $_GET['FiltroPrecoCondicao'] != "false")
{
	$filtro['FiltroPrecoCondicao'] = $_GET['FiltroPrecoCondicao'];
}

if(!empty($_GET['FiltroCor']) && $_GET['FiltroCor'] != "false")
{
	$filtro['FiltroCor'] = $_GET['FiltroCor'];
}

/* Busca Produtos */
$listagem = $controller->Listar($filtro);
/* Aplica regra de negócio dos descontos */
$listagem = $controller->RegraDeDesconto($listagem);

?>

<html>
	<head>
		<Title>Listagem</title>
	</head>
<body>
<h1> Listagem de Produtos </h1>
	<!-- Filtros -->
	<table>
		<tr>
			<td>Filtros :</td>
		</tr>
		<form <form action="produtosList.php">
		<tr>		
			<td>Nome :</td>
			<td><input type="text" id="FiltroNome" name="FiltroNome"/>
			<td> Cor : </td>
			<td> 
				<select id="FiltroCor" name="FiltroCor">
					<option value="false">Selecione</option>
					<?php foreach($cores as $key => $value) { ?>
					<option value="<?=$key; ?>"><?=$value; ?></option>
					<?php } ?>
				</select>
			<td> Preço : </td>
			<td> 
			<select id="FiltroPrecoCondicao" name="FiltroPrecoCondicao">
				<option value="false">Condição</option>
				<option value=">">Maior</option>
				<option value="<">Menor</option>
				<option value="=">Igual</option>
			</select>
			<td> <input type="text" id="FiltroPrecoValor" name="FiltroPrecoValor"/></td>
			<td> <input type="submit" value="Pesquisar" />
		</tr>
		</form>
	</table>
		<!-- /Filtros -->
	
	<br />
	
	<!-- Listagem dos Produtos -->
	<table border=1>
		<tr>
			<td>Produto</td>
			<td>Preço</td>
			<td>Cor</td>
			<td>Desconto</td>
			<td>Ação<td>
		</tr>
		<?php if(!empty($listagem[0])) { 
					foreach($listagem as &$value) { ?>
		<tr>
			<td><?=$value->Nome; ?></td>
			<td>R$ <?= number_format($value->Preco->Preco, 2, ',', '.') ?></td>
			<td><?=$value->Cor; ?></td>
			<td><?=$value->PercDesconto; ?></td>
			<td><a href="ProdutosUpdate.php?IdProd=<?=$value->IdProd; ?>">Alterar</a> 
			<td><a href="ProdutosDelete.php?IdProd=<?=$value->IdProd; ?>">Deletar</a>  
		</tr>
					<?php } } ?>	
	</table>
	<!-- /Listagem dos Produtos -->
	
	<br />
	<!-- Novo Produto -->
	<table>
		<tr>
			<td><input type="button" value="Novo" onclick="window.open('ProdutosInsert.php','_SELF');" /></td>
		</tr>
	</table>
		<!-- /Novo Produto -->
	

</body>


<?php
?>
<html>
	<head>
		<Title>Exclusão</title>
	</head>
<body>

<?php
/*
* Desenvolvedor : Juliana E. Antunes
* Data : 22/12/2020
* Objetivo : View da Exclusão de Produto
*/
require_once("Controller/ProdutosController.php");
require_once("Model/ProdutosModel.php");


if(!empty($_GET["IdProd"])){
	$controller = new ProdutosController();
	$controller->Deletar($_GET["IdProd"]);

	echo "Produto Deletado com Sucesso";
	echo '<BR> <a href="ProdutosList.php">Voltar para Lista</a>';
	return;
}

?>
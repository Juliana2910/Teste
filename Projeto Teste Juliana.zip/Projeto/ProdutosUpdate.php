<?php
/*
* Desenvolvedor : Juliana E. Antunes
* Data : 22/12/2020
* Objetivo : View da Alteração de Produto
*/

require_once("Controller/ProdutosController.php");
require_once("Model/ProdutosModel.php");


if(!empty($_POST['Alterar'])){
	/* Quando ação for alterar produto */
	$produto = new Produto();
	$produto->Nome = $_POST['Nome'];
	$produto->Preco = new Preco();
	$produto->Preco->Preco = $_POST['Preco'];
	$produto->IdProd = $_POST['IdProd'];
	
	$controller = new ProdutosController();
	$controller->Alterar($produto);
	
	echo "Produto Alterado com sucesso!";
	echo '<BR> <a href="ProdutosList.php">Voltar para Lista</a>';
	return;

}else{
	/* Popula View */
	$controller = new ProdutosController();
	/* Popula DropDown de cores */
	$cores = $controller->ObterCores();
	
	$produto = $controller->Obter($_GET["IdProd"]);
}

?>

<html>
	<head>
		<Title>Atualização</title>
	</head>
<body>
<h1>Alterar</h1>

<form action="ProdutosUpdate.php" method="POST">
	<table>
		<tr>
			<td>Produto : </td>
			<td><input type="text" id="Nome" name="Nome" value="<?=$produto->Nome; ?>" /></td>
		<tr>
		<tr>
			<td>Preço : </td>
			<td><input type="text" id="Preco" name="Preco" value="<?=$produto->Preco->Preco; ?>"/></td>
		<tr>
		<tr>
			<td>Cor : </td>
			<td>
				<select id="Cor" name="Cor" disabled>
					<option value="false">Selecione</option>
					<?php foreach($cores as $key => $value) { ?>
						<?php if($key==$produto->Cor) { ?>
						<option value="<?=$key; ?>" selected><?=$value; ?></option>
						<?php }else { ?>
					<option value="<?=$key; ?>"><?=$value; ?></option>
						<?php } ?>
					<?php } ?>
				</select>
			</td>
		</tr>
		<tr>
		<input type="hidden" value="<?=$_GET["IdProd"]; ?>" name="IdProd" id="alterar" />
		<input type="hidden" value="true" name="Alterar" id="Alterar" />
			<td><input type="submit" value="Salvar" /></td>
		<tr>
	</table>
<form>